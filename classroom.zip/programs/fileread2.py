# the whole file will be displayed as one sstring
# fobj can be called as file pointer or file reference 
with open("data.txt","r") as fobj:
    print(fobj.read())


# will display n no. of characters
with open("data.txt","r") as fobj:
    print(fobj.read(4))
