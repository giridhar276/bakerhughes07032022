
import os
import shutil

source = r"D:\trainings\edyoda070332022\source"

destination = r"D:\trainings\edyoda070332022\destination"

os.chdir(source)
for file in os.listdir():
    #print(file)
    if os.path.exists(destination + "\\" +  file):
        print(file,"already exists in ", destination)
    else:
        shutil.copy(file,destination)
        print(file,"copied to ",destination)


    
    
