
# if any object is prefixed with * ... it becomes tuple

def display(*arguments):
    for val in arguments:
        print(val)
display(10,20,30,"unix","perl","scala")


# if any object is prefixed with * ... it becomes dictionary
def displayoutput(**kargs):
    for key,value in kargs.items():
        print(key,value)

displayouput(chap1 = 10 , chap2 = 20)
