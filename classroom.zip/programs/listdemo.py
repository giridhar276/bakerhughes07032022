# list
alist = [12,23,34,54,43,67,54]
alist[0] = 100
print("After replacing :", alist)




atup = (34,45,32,54,9)

atup[0] = 100

print("After replacing :", atup)
