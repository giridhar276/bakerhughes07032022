import time
import os
import datetime
file1 = "ip2.py"
file2 = "userdefined5.py"


#print(time.time())

#print( os.path.getsize(file))



file1epoch = int(os.stat(file1).st_mtime)
file2epoch = int(os.stat(file2).st_mtime)

if file1epoch < file2epoch:
    print(file2,"is the latest file")
    print(datetime.datetime.fromtimestamp(file2epoch).strftime("%Y-%m-%d"))
else:
    print(file1,"is the latest file")
    print(datetime.datetime.fromtimestamp(file1epoch).strftime("%Y-%m-%d"))
    
