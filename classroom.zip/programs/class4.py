


class Employee:
    def getDetails(self,empid,name,address):
        self.empid = empid
        self.name = name
        self.address = address
    def displayDetails(self):
        print("Emp ID  :", self.empid)
        print("Name    :", self.name)
        print("Address :", self.address)


# object creation
emp1 = Employee()
emp1.getDetails(1,"Ram","Miyapur,Hyderabad")
emp1.displayDetails()



emp2 = Employee()
emp2.getDetails(2,"Rita","MGRoad,Chennai")
emp2.displayDetails()
