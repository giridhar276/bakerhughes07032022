# variable length args
# If any object is prefixed with * ... it is called as tuple
def add(*args):
    print(type(args))
    for val in args:
        print(val)

add(10,20,30,"unix","linux")


#If any object is prefixed with ** ... it is called as dictionary

def display(**dictvalues):
    #print(type(dictvalues))
    for key,value in dictvalues.items():
        print(key,value)




display(chap1 = 10 , chap2 = 20)
