# method1
# importing all the methods to your program space
import math  # 200 methods
print(math.tan(2))
print(math.floor(45.3))



# method2
# importing with alias
import math as m
print(m.tan(2))
print(m.log(1))


# method3
# importing
from math import log,cos,ceil
print(log(4))
print(cos(1))
print(ceil(45.3))

