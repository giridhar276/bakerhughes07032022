
#method1
# all the methods will be imported to your program space
import math
print("importing all the methods ")
print(math.floor(4.4))
print(math.pi)
print(math.tan(3))


# method2   - importing with alias name
import math as m
print("importing all the methods with alias name")
print(m.floor(4.4))
print(m.pi)
print(m.tan(3))


# method3 -  importing required methods only
from math import log,tan,ceil,floor   # only these methods will be imported
# . is not required to accesss the methods
print("importing required methods only")
print(log(2))
print(tan(1))
print(ceil(34.9))
print(floor(34.9))
