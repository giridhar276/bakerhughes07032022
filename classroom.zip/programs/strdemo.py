

print(10,20,30,3.4432)

print("python","java")

name = "python programming"
print(name)

print(name.capitalize())
print(name.upper())
print(name.lower())

print(name.split(" "))

print(name.isupper())

print(name.find('t'))
print(name.find('z'))   # -1 if  z is not found

aname  = " python "
print(len(aname))

print(len(aname.strip()))  # will remove whitespaces at both the ends
print(len(aname.lstrip()))
print(len(aname.rstrip()))


print(name.isupper())
print(name.islower())
print(name.isalpha())
print(name.isalnum())



if name.isupper() :
    #inside if condition
    print("String is upper")
    print("Inside if condition")
    print("Still inside if cond")
else:
    #inside else
    print("String is lower")
    print("Inside else block")
    print("still inside else")
print(10,20,30)


name = "python programming"
if name.startswith("p"):
    output = name.split(" ")
    print(output[0])
    print(output[1])
else:
    print(name.upper())


if name.endswith("ing"):
    print("Its.. python programming")
elif name.endswith("va"):
    print("Its.. java programming")
elif name.endswith("ix"):
    print("Its unix")
else:
    print("default one")



print(name.replace("python","ruby"))
print("orig:", name)


#slicing
#string[start:stop:step]
name = "python programming"
print(name[0])
print(name[1])
print(name[0:6])
print(name[1:8])
print(name[::])
print(name[:])
print(name[0:18:2])
print(name[1:18:2])
print(name[1:18:4])
print(name[3:])
print(name[-1])
print(name[-3])
print(name[-5:-2])
print(name[::-1])

output = name[::-1]
print(output)



#loop
for val in range(1,10): # 1 to 9
    print(val)

name = "python"
for char in name:
    print(char)

for val in range(10):   # 0 to 9
    print(val)

for val in range(1,10,2):   # 1,3,5,7,9
    print(val)

name = "python"
for char in range(0,len(name) ,2):
    print(name[char])


name = "python"
for char in range(0,len(name) ,2):
    print(name[char] , end= " ")
    


































