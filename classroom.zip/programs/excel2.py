
import csv
from openpyxl import Workbook
import time
wb = Workbook()
ws = wb.active
with open("realestate.csv","r") as fobj:
    reader = csv.reader(fobj)
    for line in reader:
        street = line[0]
        city = line[1]
        ws.append([street,city])
        

filename = time.strftime("%d_%b_%Y.xlsx")

wb.save(filename)
