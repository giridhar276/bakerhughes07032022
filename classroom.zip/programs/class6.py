
import csv
class ReadFile:
    def __init__(self,filename):
        self.filename = filename
    def displayContent(self):
        self.fobj= open(self.filename,"r")
        self.reader = csv.reader(self.fobj)
        for line in self.reader:
            print(line)
    

obj1 = ReadFile("realestate.csv")
obj1.displayContent()
