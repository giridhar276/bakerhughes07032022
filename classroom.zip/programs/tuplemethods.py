

atup = (45,34,32,34,23,23)

print(atup)

