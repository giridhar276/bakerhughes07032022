




def add():
    print("this is add")
def sub():
    print("this is sub")



sub()
add()
