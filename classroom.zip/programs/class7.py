
import csv
class ReadFile:
    def __init__(self,filename):
        self.filename = filename
    def readFile(self):
        self.fobj= open(self.filename,"r")
    def displayContent(self):
        self.reader = csv.reader(self.fobj)
        for line in self.reader:
            print(line)    


obj1 = ReadFile("realestate.csv")
#obj1.readFile()
obj1.displayContent()
