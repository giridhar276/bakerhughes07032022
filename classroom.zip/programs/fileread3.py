
'''
# output will be displayed in the list format
with open("data.txt","r") as fobj:
    print(fobj.readlines())
'''
# output will be displayed in the list format
with open("data.txt","r") as fobj:
    print(fobj.readlines()[1:3])


# displaying line by line
with open("data.txt","r") as fobj:
    for line in fobj.readlines()[2:4]:
        print(line)

