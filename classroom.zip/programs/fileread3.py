
# reading line by line
with open("lang.txt","r") as fobj:
    for line in fobj:   # always checks for EOF
        # remove whitespaces if any
        line = line.strip()
        print(line)
