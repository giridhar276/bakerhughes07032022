
import os
try:
    files = os.listdir()
    for file in files:
        if file.endswith(".csv"):
            print(file)

except Exception as err:
    print(err)


#write a program to delete all .csv files
#from the current directory
import os
try:
    files = os.listdir()
    for file in files:
        if file.endswith(".csv"):
            os.remove(file)

except Exception as err:
    print(err)

