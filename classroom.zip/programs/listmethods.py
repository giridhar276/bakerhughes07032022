alist = [10,89,56,34,12,65,32]


# list.append() - add single object
alist.append(89)
print("After appending :", alist)
alist.append(90)
print("After appending :", alist)

# list.extend()  - add multiple values
alist.extend([87,43,21])
print('After extending :',alist)

#list.insert(position,value)   -- insert at any index
alist.insert(2,1000)
print('After insert :', alist)

# list.pop(index)
alist.pop(2)  # delete value at index 2
print("After pop :",alist)

# list.remove(value)  - remove the value directly
alist.remove(65)
print('After removing :', alist)

alist.remove(65)
print('After removing :', alist)

if 65 in alist:
    alist.remove(65)
else:
    print(65, "doesn't exist in list")

    






    



