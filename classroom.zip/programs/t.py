
fobj = open("languages.txt","w")   # file will be created in your current working directory
fobj.write("python programming\n")
fobj.write("scala programming\n")

fobj.close()



#fobj = open("D:/trainings/edyoda070332022/languages.txt","w")  #or
#fobj = open(r"D:\trainings\edyoda070332022\languages.txt","w")    # raw string
fobj = open("D:\\trainings\\edyoda070332022\\languages1.txt","w")
fobj.write("python programming\n")
fobj.write("scala programming\n")
fobj.close()


#
fobj = open("numbers.txt","w")
for val in range(1,10):
    fobj.write(str(val) + "\n")

fobj.close()
