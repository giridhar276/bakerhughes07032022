
import csv
import sys
try:
    with open("data.txt","r") as fobj:
        # converting file object to csv object
        reader  = csv.reader(fobj, delimiter=":")
        for line in reader:
            print(line)
    #
    alist = [10,20,30]
    print(alist[2])
except FileNotFoundError as err:
    print(err)
except TypeError as err:
    print(err)
    print(sys.exc_info())
except ValueError as err:
    print(err)
    print(sys.exc_info())
except (IndexError,KeyError,PermissionError) as err:
    print(err)
    print(sys.exc_info())
except Exception  as error:
    print("file not found...")
else:
    adict = {"chap1":10 ,"chap2":20}
    for key,value in adict.items():
        print(key,value)
