
import csv

with open("lang.txt","r") as fobj:
    # convert file object to csv object
    reader = csv.reader(fobj)
    for line in reader:
        print(line)
