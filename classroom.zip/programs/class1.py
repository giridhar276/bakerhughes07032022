



class Employee:
    def displayEmployee(self):
        print("Employee name is :", "ram")
    def getAddress(self):
        print("Address :", "Hyderabad")


# object creation
emp1 = Employee()
emp1.displayEmployee()
emp1.getAddress()



emp2 = Employee()
emp2.displayEmployee()
emp2.getAddress()



