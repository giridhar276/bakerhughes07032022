#write a program to read realestate.csv and before displaying ..
#replace SACRAMENTO with HYDERABAD.
try:
    filename = "realestate.csv"
    # reading the file
    with open(filename) as fobj:
        # writing to the file
        with open("output.csv","w") as fw:
            for line in fobj:
                line = line.strip()
                # some operation
                line = line.replace("SACRAMENTO","HYDERABAD")
                # writing to the file
                fw.write(line + "\n")
except FileNotFoundError as err:
    print(err)
except Exception as err:
    print(err)

