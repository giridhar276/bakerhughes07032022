


# function definition
def add(a= 0,b = 0):
    print(a,b)


# calling function
add()
add(10)
add(10,20)
