

import re
with open("example.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search("[mqz]ython",line):
            print(line)




        
import re
with open("example.txt","r") as fobj:
    for line in fobj:
        line = line.strip()
        if re.search("pyt{1,4}hon",line):    #python   #pytthon  #pytttthon  #pytttttthon(INvalid)
            print(line)
