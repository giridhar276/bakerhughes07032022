colors = [
   {
     "colors": "red",
     "values": "#f00"
   },
   {
     "colors": "green",
     "values": "#0f0"
   },
   {
     "colors": "yellow",
     "values": "#ff0"
   },
   {
     "colors": "black",
     "values": "#000"
    }
]

#print(type(colors))

'''
red(#f00)
green(#ofo)
yellow(#ff0)
black(#000)
'''

for item in colors:
    print(item["colors"],"(",item["values




                                  
