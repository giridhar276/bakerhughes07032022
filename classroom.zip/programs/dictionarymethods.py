adict = {"chap1":10 , "chap2":20 }
# new key-value pairs
adict["chap3"] = 30
adict["chap4"] = 40
print(adict)
adict = {'chap1': 10, 'chap2': 20, 'chap3': 30, 'chap4': 40 ,"chap1":100}
print(adict)
print(adict["chap1"]) #100

print(adict.keys())  # display keys
print(adict.values()) # display values
print(adict.items())  ## display key:value items

# delete key:value pair
adict.pop("chap1")
print("After pop :", adict)

adict.popitem() ## remove last key-value pair
print(adict)

#print(adict["chap8"])
print(adict.get("chap8")) # None if chap8 is not existing
print(adict.get("chap3"))


bdict = {"chap7":70 ,"chap8":80}
adict.update(bdict)  # all the item of B will be updated to A
print(adict)



print(adict)
# display Keys
for key in adict.keys():
    print(key)

# display keys
for key in adict:
    print(key)


# display values
for value in adict.values():
    print(value)

# display key:value at a time
for key,value in adict.items():
    print(key,value)

















