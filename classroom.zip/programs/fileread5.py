#3
# reading the file all at once
with open("lang.txt","r") as fobj:
    print(fobj.readlines())   # list output

# reading the file all at once
with open("lang.txt","r") as fobj:
    print(fobj.readlines()[2:4])   # list output

# using for loop
# reading the file all at once
with open("lang.txt","r") as fobj:
    for line in fobj.readlines()[2:4] :
        print(line)
