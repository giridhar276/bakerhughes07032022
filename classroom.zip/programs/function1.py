

# fixed arguments
# function definition
def display(a,b):
    print(a,b)

# calling function

display(10,20)
