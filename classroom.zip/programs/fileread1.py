

# reading line by line
# fobj can be called as file
#pointer or file reference 
with open("data.txt","r") as fobj:
    for line in fobj:
        # will remove whitespaces if any
        line = line.strip()
        print(line)



