
# traditinal way
# old style
# regular approach
# fobj acts as file reference of file handler or file pointer
fobj = open("lang.txt","r")

for line in fobj:   # always checks for EOF
    # remove whitespaces if any
    line = line.strip()
    print(line)

fobj.close()
