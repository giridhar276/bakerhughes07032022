



import csv

try:
    with open("data111.txt","r") as fobj:
        # converting file object to csv object
        reader  = csv.reader(fobj, delimiter=":")
        for line in reader:
            print(line)
except Exception  as error:
    print("file not found...")
    
