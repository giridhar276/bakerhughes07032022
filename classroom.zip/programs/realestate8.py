
import csv
try:
    filename = "realestate.csv"
    # reading the file
    with open(filename) as fobj:
        # writing to the file
        with open("output.csv","w") as fw:
            reader = csv.reader(fobj)
            for line in reader:
                if line[1] == "SACRAMENTO" :
                    line[1] = "HYDERABAD"
                # writing to the file
                line = ",".join(line)
                fw.write(line + "\n")
except FileNotFoundError as err:
    print(err)
except Exception as err:
    print(err)
