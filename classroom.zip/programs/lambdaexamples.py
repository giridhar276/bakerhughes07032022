# function definition
def add(a,b):
    c = a+ b  #
    return c
# calling function
total = add(10,20)
print(total)

#lambda function  ( inline function or nameless function)
#the function body(lambda expression) will be replaced in the calling function
# lambda is the replacement of single liner function
# lambda is faster compared to the definition
#funct = lambda variables : expression
add = lambda x,y : x+y
# calling function
total = add(10,20)
print(total)

# c style    # legacy style
alist = [10,20,30]
blist = []
for val in alist:
    blist.append(val + 5)
print(blist)

#map(function,iterable)
def increment(x):
    return x + 5
print(list(map(increment,alist)))

#using lambda
print(list(map(lambda x: x + 5,alist)))
#[10,20,30]
#[15,25,35]   # updated list



alist = [1,2,3,4,5,6,7,8,9,12,23,34]
print(list(filter(lambda x : x%2==0 , alist)))  # even no.
print(list(filter(lambda x : x%2==1 , alist)))  # odd no.






































    











