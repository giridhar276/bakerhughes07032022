

atup = (45,43,56,3)
print(atup)


