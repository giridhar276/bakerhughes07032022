class Employee:
    def __init__(self,empid,name,address):
        self.empid = empid
        self.name = name
        self.address = address
    def displayDetails(self):
        print("Emp ID  :", self.empid)
        print("Name    :", self.name)
        print("Address :", self.address)


# object creation
#constructor :
#constructor will be ivoked automatically when the
#                 object is created
#general use of constructors
#constructors are used to initialize the values
emp1 = Employee(1,"Ram","Miyapur,Hyderabad")
emp1.displayDetails()

emp2 = Employee(2,"Rita","MGRoad,Chennai")
emp2.displayDetails()
