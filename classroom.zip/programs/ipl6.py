'''
write a program to read the file and display all the
lines where country is IND with proper exception handling
'''
import csv
countrylist = list()
try:
    with open("IPL.csv","r") as fobj:
        header = fobj.readline()
        #converting file object to csv object
        reader = csv.reader(fobj)
        for line in reader:
            #processing
            if "IND" in line:
                print(line)
except FileNotFoundError as err:
    print(err)
except Exception as err:
    print(err)                
