
# fixed arguments
# function definition
def add(a,b):
    print(a,b)


# calling function
add(10,20)
