# keyword args
def add(c,b,a):
    print(a,b,c)

add(a = 10 , b = 20, c = 30)
