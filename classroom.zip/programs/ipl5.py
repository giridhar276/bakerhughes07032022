import csv
countrydict = dict()
try:
    with open("IPL.csv","r") as fobj:
        header = fobj.readline()
        #converting file object to csv object
        reader = csv.reader(fobj)
        for line in reader:
            #processing
            country = line[3]
            countrydict[country] = 1
        for coun in countrydict:
            print(coun)
except FileNotFoundError as err:
    print(err)
except Exception as err:
    print(err)
