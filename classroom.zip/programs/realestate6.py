#write a program to read realestate.csv and before displaying ..
#replace SACRAMENTO with HYDERABAD.
try:
    filename = "realestate.csv"
    with open(filename) as fobj:
        for line in fobj:
            line = line.strip()
            line = line.replace("SACRAMENTO","HYDERABAD")
except FileNotFoundError as err:
    print(err)
except Exception as err:
    print(err)
