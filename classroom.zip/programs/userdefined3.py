
# default args
# function definition
def add(a=0,b=0,c=0):
    print(a,b,c)


# calling function
add()    # 0 0 0 
add(1)   # 1 0 0
add(1,2) # 1 2 0
add(1,2,3)#1 2 3
