

from openpyxl.workbook import Workbook
import csv

wb = Workbook()
wb.remove(wb['Sheet'])


ws1 = wb.create_sheet("Sheet_A")
ws1.title = "Title_A"

ws2 = wb.create_sheet("Sheet_B", 0)
ws2.title = "Title_B"

with open("realestate.csv","r") as fobj:
    reader = csv.reader(fobj)
    for line in reader:
        street = line[0]
        city = line[1]
        ws2.append([street,city])
        ws1.append([street,city])
        
wb.save(filename = 'sample_book.xlsx')
