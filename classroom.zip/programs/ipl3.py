'''
write a program to display all the unique playing role with proper exception handling
Allrounder
Bowler
Bastsman
Wickerkeeper
'''

import csv
roleset = set()
try:
    with open("IPL111.csv","r") as fobj:
        header = fobj.readline()
        #converting file object to csv object
        reader = csv.reader(fobj)
        for line in reader:
            #processing
            playingrole = line[5]
            roleset.add(playingrole)
        # display the output
        for role in roleset:
            print(role)
except FileNotFoundError as err:
    print(err)
except Exception as err:
    print(err)
