

class Employee:
    def displayEmployee(self,name):
        self.name = name
        print(name)
    def getAddress(self,address = "India"):
        self.address = address
        print("Address :", self.address)




# object creation
emp1 = Employee()
emp1.displayEmployee("Ram")
emp1.getAddress("Miyapur,Hyderabad")



emp2 = Employee()
emp2.displayEmployee("Rita")
emp2.getAddress()
