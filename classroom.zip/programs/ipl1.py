import csv

try:
    with open("IPL.csv","r") as fobj:
        for line in fobj:
            line = line.strip()
            print(line)
except FileNotFoundError as err:
    print(err)
except Exception as err:
    print(err)
        
